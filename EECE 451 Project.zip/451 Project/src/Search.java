import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;


import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;


public class Search extends JFrame {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JPanel contentPane;
	private JButton btnNewButton;
	private JButton btnNewButton1;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search frame = new Search();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	/**
	 * Create the frame.
	 */
	public Search() {
		String phone_no =JOptionPane.showInputDialog(null, "Search for patient (by Phone Number)", "Save",1);
		setBackground(new Color(47, 79, 79));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 738, 359);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(72, 61, 139));
		contentPane.setBorder(new LineBorder(new Color(0, 0, 139), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel_1 = new JLabel("<html> Would like to search for the client with Phone Number: " + phone_no+ "?", SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 11, 712, 155);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Consolas", Font.BOLD, 28));

		btnNewButton = new JButton("Yes");
        btnNewButton.setFont(new Font("Harlow Solid Italic", Font.PLAIN, 26));
        btnNewButton.setBounds(160, 246, 135, 33);
        contentPane.add(btnNewButton);
        btnNewButton.addActionListener(new ActionListener() {
             	public void actionPerformed(ActionEvent e) {
             		try {
             			Class.forName("com.mysql.cj.jdbc.Driver");  
            			Connection con=DriverManager.getConnection(  
            					"jdbc:mysql://localhost:3306/register","root","");   
             			
            			Statement stmt= con.createStatement();
     					//PreparedStatement stmt =con.prepareStatement("Select * FROM client_account WHERE `Phone no` = '"+phone_no +"'");
     					String slct ="Select * FROM client_account WHERE `Phone no` = '"+phone_no +"'";
     					ResultSet x = stmt.executeQuery(slct);
            			while(x.next()) {
            				System.out.println("Full Name: "+x.getString("Full name"));
            				System.out.println("Date of Birth: "+x.getString("DOB"));
            				System.out.println("ID Number: "+x.getString("ID no"));
            				System.out.println("Phone Number: "+x.getString("Phone no"));
            				System.out.println("Email: "+x.getString("Email"));
            				System.out.println("City: "+x.getString("City"));
            				System.out.println("Country "+x.getString("Country"));
            				System.out.println("Medical Conditions: "+x.getString("Medical Conditions"));
            				System.out.println("Username "+x.getString("Username"));
            				System.out.println("Password: "+x.getString("Password"));
            			}
             		}
             		//if (online_users=TCPClient.users) {
             			
             	 catch (ClassNotFoundException | SQLException e1) {
     				// TODO Auto-generated catch block
     				e1.printStackTrace();
     			}  
             	//}
             	
             	}
             	});
             	
  
        btnNewButton1 = new JButton("No");
        btnNewButton1.setFont(new Font("Harlow Solid Italic", Font.PLAIN, 26));
        btnNewButton1.setBounds(441, 246, 135, 33);
        contentPane.add(btnNewButton1);
        btnNewButton1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Search sh = new Search();
        		sh.setVisible(true);
        	}
        });
        
	}
	}