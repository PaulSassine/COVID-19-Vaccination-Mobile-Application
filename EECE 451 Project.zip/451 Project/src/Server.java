
import java.io.*;
import java.sql.*;
import java.net.*;


public class Server {
	
	private int port = 1915;
	private ServerSocket serverSocket;
	public void acceptConnections() {
	try {
	serverSocket = new ServerSocket(port); }
	catch (IOException e) {
	System.err.println("ServerSocket instantiation failure"); e.printStackTrace();
	System.exit(0);
	}

	while (true) {
	      try {
	//wait for a TCP handshake (arrival of a "SYN" packet)
	Socket newConnection = serverSocket.accept();
	System.out.println("accepted connection");
	//Now, pass the connection socket created to a thread and run it in it //First create the thread and pass the connection socket to it //This is the constructor of the class ServerThread
	ServerThread st = new ServerThread(newConnection);
	//Start the thread, and go back to waiting for another TCP connection
	new Thread(st).start(); }
	catch (IOException ioe) {
	System.err.println("server accept failed"); }
}
	}
	
	public static void main(String args[]) {
	
		Server server=new Server();
		server.acceptConnections();
	}
	class ServerThread implements Runnable {
		private Socket socket;
		private BufferedReader inFromClient; private DataOutputStream OutToClient;
		public ServerThread(Socket socket) {
		//Inside the constructor: store the passed object in the data member
		this.socket = socket; }
		public void run() {
			
		try {
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader (socket.getInputStream()));
			PrintWriter write= new PrintWriter(socket.getOutputStream(),true);
			String query= inFromClient.readLine();
//			String query2=inFromClient.readLine();
//			String type=inFromClient.readLine();
			System.out.println("hi");
			System.out.println(query);	
			
			if (query!="stop" )
			{ if (query!=null  ) {
				
					try { 
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/register","root","");
						System.out.println("connection established");
						Statement stmt= conn.createStatement();
						//String query="INSERT INTO account (Full_name,Username,Email,password) values(' "+ name +"','" + username + "','" +
		                      //  email + "','" + password + "')";
						//System.out.println("the SQL statement is:"+query+ "\n"); 
						if (query.startsWith("INSERT")) {
							int x = stmt.executeUpdate(query);
							System.out.println(x);
					
						}
						else if(query.startsWith("SELECT")) {
							ResultSet x = stmt.executeQuery(query);
							System.out.println(x);
						}
						
						//if (x==1) {
							//DataOutputStream outToClient = new DataOutputStream(socket.getOutputStream());
							//outToClient.writeInt(x);
						//}
						}
						
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ClassNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
					
					
		
					
			
			
			
			//DataOutputStream outToClient = new DataOutputStream(socket.getOutputStream());
		   
		     
		     //String clientSentence = inFromClient.readLine(); 
		     
		     //String capitalizedSentence = clientSentence.toUpperCase() + '\n'; 

		     //outToClient.writeBytes(capitalizedSentence);
				}
			//if (query!=null) {
				//try { 
				//	Class.forName("com.mysql.jdbc.Driver");
					//Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:8889/register","root","root");
					//System.out.println("logging in");
					

					//Statement stmtt= conn.createStatement();
					//ResultSet x1 = stmtt.executeQuery(query);
				//	System.out.println(x1);
					//if(x1.next()) {
						
						//if(login_system.password.equals(x1.getString("password"))) {
							
						//	System.out.println("1"); //send 1 to the client if sign in worked 
	
						//}
						//else {
							//System.out.println("0");
						//}
					//}
					//else {
						
						 //System.out.println("username " + username);
			            // System.out.println("password " + password);
			           //  System.out.println("Incorrect username/password combination");
					//}
				//}
				//catch (SQLException e) {
					// TODO Auto-generated catch block
				//e.printStackTrace();
				//} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
					//e.printStackTrace();
					//}
				
			//}
		//	}
//			}
			}}
		catch (IOException e) {
			return; }
		
	finally {
		try {
			socket.close();
		}
		catch(IOException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Closed:" + socket);
	}
				}
			}
			}
			