import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Image;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.awt.SystemColor;

public class login extends JFrame {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

	private JPanel contentPane;

	private Image img_logo = new ImageIcon(login.class.getResource("imgs/staysafe.png")).getImage().getScaledInstance(180,180, Image.SCALE_SMOOTH);
	private Image img_user = new ImageIcon(login.class.getResource("imgs/user.png")).getImage().getScaledInstance(20,20, Image.SCALE_SMOOTH);
	private Image img_pass = new ImageIcon(login.class.getResource("imgs/pass.png")).getImage().getScaledInstance(20,20, Image.SCALE_SMOOTH);
	private JTextField textField;
	private JPasswordField passwordField;
	private JButton btnNewButton;
	private JButton btnNewButton1;
	private JButton btnNewButton2;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		
		 
		setBackground(new Color(47, 79, 79));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 802, 519);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new LineBorder(new Color(0, 0, 139), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(0, 0, 224, 481);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel Logo = new JLabel("");
		Logo.setBounds(22, 94, 172, 189);
		panel.add(Logo);
		Logo.setIcon(new ImageIcon(img_logo));
		
		JButton btnNewButton3 = new JButton("Register");
		 btnNewButton3.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		registration r = new registration();
	        			r.setVisible(true);	
	        	}
	        });
		btnNewButton3.setBounds(42, 333, 135, 34);
		panel.add(btnNewButton3);
		btnNewButton3.setFont(new Font("Harlow Solid Italic", Font.PLAIN, 22));
		
		textField = new JTextField();
		textField.setBounds(357, 176, 269, 39);
		textField.setFont(new java.awt.Font("Verdana Pro", 1, 14));
		textField.setForeground(new java.awt.Color(46, 50, 60));
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(357, 256, 269, 39);
		passwordField.setFont(new java.awt.Font("Verdana Pro", 1, 14));
		passwordField.setForeground(new java.awt.Color(46, 50, 60));
		contentPane.add(passwordField);
		
		JLabel PassIcon = new JLabel("");
		PassIcon.setBounds(325, 243, 46, 75);
		contentPane.add(PassIcon);
		PassIcon.setIcon(new ImageIcon(img_pass));
		
		
		JLabel lblNewLabel = new JLabel(" Welcome!");
		lblNewLabel.setBounds(394, 36, 208, 75);
		contentPane.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Harlow Solid Italic", Font.BOLD, 35));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		
		JLabel UserIcon = new JLabel("");
		UserIcon.setBounds(325, 141, 46, 114);
		contentPane.add(UserIcon);
		UserIcon.setIcon(new ImageIcon(img_user));
		
		btnNewButton = new JButton("Admin");
		btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		String Username = textField.getText();
        	    String password = String.valueOf(passwordField.getPassword());
        	    String type = "LOG IN";
        	    String query2 = "SELECT * FROM account WHERE `Username` = '"+ Username +"' && `password` = '"+password+"'";
        	    
        	    System.out.println("the SQL statement is:"+query2+ "\n"); 
				
        	
        		TCPClient.client_write.println(query2);
        		admin_Access aa = new admin_Access();
        		aa.setVisible(true);
        	}
        });
        btnNewButton.setFont(new Font("Harlow Solid Italic", Font.PLAIN, 22));
        btnNewButton.setBounds(441, 402, 135, 33);
        contentPane.add(btnNewButton);
        
        JButton btnNewButton1 = new JButton("Patient");
        btnNewButton1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		String Username = textField.getText();
        	    String password = String.valueOf(passwordField.getPassword());
        	    String type = "LOG IN";
        	    String query2 = "SELECT * FROM client_account WHERE `Username` = '"+ Username +"' && `Password` = '"+password+"'";
        	    
        	    System.out.println("the SQL statement is:"+query2+ "\n"); 
				
        	    System.out.println(Username);
        		TCPClient.client_write.println(query2);
        		
            	patient_Access pa = new patient_Access();
            	pa.setVisible(true);
        	//	patient_Access pa = new patient_Access();
        		//pa.setVisible(true);
        	}
        });
        btnNewButton1.setBounds(254, 402, 135, 33);
        contentPane.add(btnNewButton1);
        btnNewButton1.setFont(new Font("Harlow Solid Italic", Font.PLAIN, 22));
        
        JButton btnNewButton2 = new JButton("Personnel");
        btnNewButton2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		String Username = textField.getText();
        		String password = String.valueOf(passwordField.getPassword());
        	    String type = "LOG IN";
        	    String query2 = "SELECT * FROM client_account";
        	    
        	    System.out.println("the SQL statement is:"+query2+ "\n"); 
				
        	
        		TCPClient.client_write.println(query2);
        		personnel_Access ppa = new personnel_Access();
        		ppa.setVisible(true);
        	}
        });
        btnNewButton2.setBounds(621, 402, 135, 33);
        contentPane.add(btnNewButton2);
        btnNewButton2.setFont(new Font("Harlow Solid Italic", Font.PLAIN, 22));
        
        
        
        JLabel lblNewLabel_1 = new JLabel("log in as..");
        lblNewLabel_1.setForeground(Color.WHITE);
        lblNewLabel_1.setFont(new Font("Harlow Solid Italic", Font.BOLD, 22));
        lblNewLabel_1.setBounds(459, 319, 105, 72);
        contentPane.add(lblNewLabel_1);
        
        
       
        

        	}
        }