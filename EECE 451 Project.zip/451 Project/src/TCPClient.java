import java.io.*;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

public class TCPClient {
	
	public static PrintWriter client_write;
	public static BufferedReader client_read;
	public static int users;
	
	 public static void main(String argv[]) throws Exception
	    {
	        Socket socket = null;
	        
	        try {
		 	
	        InetAddress host= InetAddress.getLocalHost();
	        
	        socket = new Socket(host.getHostName(),1915);
	        client_write= new PrintWriter(socket.getOutputStream(),true);
	        client_read=new BufferedReader(new InputStreamReader(socket.getInputStream()));
	        
	       /* int val= client_read.read();
	        if (val==1) {
	        	users=users+1;
	        }*/
	        login lg = new login();
	        lg.setVisible(true);
	        
	  
	        }
	       
	        catch (IOException e) {
	        	
	        	System.err.println(e);
	        }
	       // clientSocket.close();
	    }


}