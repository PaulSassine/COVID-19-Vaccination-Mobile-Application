

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JSpinner;


public class registration extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField; //email
	private JTextField textField_1; //username
	private JPasswordField passwordField; //password
	private JTextField textField_2; //full name
	private Image img_logo = new ImageIcon(registration.class.getResource("imgs/vacc.png")).getImage().getScaledInstance(180,180, Image.SCALE_SMOOTH);
	private JTextField textField_3; //dob
	private JTextField textField_4; //ID card no
	private JTextField textField_5; //city
	private JTextField textField_6; //country
	private JTextField textField_7; //medical condition
	private JTextField textField_8; //phone no
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					registration frame = new registration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public registration() {
		
		
		setBackground(new Color(47, 79, 79));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 802, 519);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new LineBorder(new Color(0, 0, 139), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 128));
		panel.setBounds(-41, 0, 851, 49);
		contentPane.add(panel);
		panel.setLayout(null);
		
			    
			    JLabel lblNewLabel_2 = new JLabel("Patient Registration");
			    lblNewLabel_2.setBounds(294, -14, 243, 75);
			    panel.add(lblNewLabel_2);
			    lblNewLabel_2.setForeground(Color.WHITE);
			    lblNewLabel_2.setFont(new Font("Harlow Solid Italic", Font.BOLD, 25));
		
		
		JButton button = new JButton("Register");
		button.setFont(new Font("Harlow Solid Italic", Font.PLAIN, 26));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button.setBounds(414, 438, 135, 33);
		contentPane.add(button);
		
		JButton button1 = new JButton("Login");
		button1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	login l = new login();
            l.setVisible(true);
        	}
        });
        button1.setFont(new Font("Harlow Solid Italic", Font.PLAIN, 26));
        button1.setBounds(194, 438, 135, 33);
        contentPane.add(button1);
		
		textField = new JTextField();
		textField.setBounds(10, 157, 265, 35);
		contentPane.add(textField);
		textField.setFont(new java.awt.Font("Verdana Pro", 1, 14));
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("USERNAME");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 203, 104, 29);
		contentPane.add(lblNewLabel);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(10, 228, 265, 35);
		textField_1.setFont(new java.awt.Font("Verdana Pro", 1, 14));
		contentPane.add(textField_1);
		
		JLabel lblNewLabel_1 = new JLabel("EMAIL");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(10, 136, 104, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("PASSWORD");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setBounds(10, 271, 104, 29);
		contentPane.add(lblNewLabel_1_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(10, 297, 265, 39);
		contentPane.add(passwordField);
		
		JLabel lblNewLabel_3 = new JLabel("FULL NAME");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBounds(10, 60, 104, 29);
		contentPane.add(lblNewLabel_3);
		
		textField_2 = new JTextField();
		textField_2.setBounds(10, 86, 265, 39);
		contentPane.add(textField_2);
		textField_2.setFont(new java.awt.Font("Verdana Pro", 1, 14));
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("PHONE NUMBER");
		lblNewLabel_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1.setBounds(10, 346, 104, 29);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("DATE OF BIRTH (dd/mm/yy)");
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setBounds(486, 60, 258, 29);
		contentPane.add(lblNewLabel_3_1);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_3.setColumns(10);
		textField_3.setBounds(486, 86, 265, 39);
		contentPane.add(textField_3);
		
		JLabel lblNewLabel_1_2 = new JLabel("ID CARD NUMBER");
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setBounds(486, 143, 258, 29);
		contentPane.add(lblNewLabel_1_2);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_4.setColumns(10);
		textField_4.setBounds(486, 164, 265, 35);
		contentPane.add(textField_4);
		
		JLabel lblNewLabel_4 = new JLabel("CITY");
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setBounds(486, 210, 258, 29);
		contentPane.add(lblNewLabel_4);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_5.setColumns(10);
		textField_5.setBounds(486, 237, 265, 35);
		contentPane.add(textField_5);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("COUNTRY");
		lblNewLabel_1_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_1_2.setBounds(486, 278, 104, 29);
		contentPane.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("ANY MEDICAL CONDITIONS");
		lblNewLabel_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1.setBounds(486, 353, 258, 29);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_6.setColumns(10);
		textField_6.setBounds(486, 306, 265, 35);
		contentPane.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_7.setColumns(10);
		textField_7.setBounds(486, 378, 265, 35);
		contentPane.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Dialog", Font.BOLD, 14));
		textField_8.setColumns(10);
		textField_8.setBounds(10, 378, 265, 35);
		contentPane.add(textField_8);
	
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    String fullname = textField_2.getText();
			    String email = textField.getText();
			    String username = textField_1.getText();
			    String dob = textField_3.getText();
			    String ID_no = textField_4.getText();
			    String city = textField_5.getText();
			    String country = textField_6.getText();
			    String med_cond = textField_7.getText();
			    String phone_no = textField_8.getText();
			    String type ="REGISTRATION";
			    String password = String.valueOf(passwordField.getPassword());
			    String query="INSERT INTO `client_account`(`Full Name`, `DOB`, `ID no`, `Phone no`, `Email`, `City`, `Country`, `Medical Conditions`, `Username`, `Password`) "
						+ "values('"+ fullname +"','" + dob + "','" + ID_no + "','" + phone_no + "','" + email + "','" + city + "','" + country + "','" + med_cond + "','" + username + "','" + password + "')";		
				System.out.println("the SQL statement is:"+query+ "\n"); 
//				String query="INSERT INTO client_account (Full name,DOB,ID no,Phone no,Email,City,Country,Medical Conditions,Username,Password) "
//				+ "values('"+ fullname +"','" + dob + "','" + ID_no + "','" + phone_no + "','" + email + "','" + city + "','" + country + "','" + med_cond + "','" + username + "','" + password + "')";		
				System.out.println("worked");
				TCPClient.client_write.println(query);
				login l = new login();
				l.setVisible(true);
//				
			}
			
			
			});
			}
	
}
	
